import Ember from 'ember';

export default Ember.View.extend({
  classNames: ['view-about']
});
